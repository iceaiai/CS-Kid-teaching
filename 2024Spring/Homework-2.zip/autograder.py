import re
import io
import sys

class auto_grader_02:
    def __init__(self):
        self.total_score = 0
        self.max_score = 60

    def check(self, your_name):
        if your_name.strip():
            print(f"Hello {your_name}!")
        else:
            print("Please enter your name.")

    def Q1(self, answer):
        expected_answer = 0.0
        if answer == expected_answer:
            self.total_score += 5
            print("Correct! You scored 5 points.")
        else:
            print(f"Incorrect. You scored 0 points.")

    def Q2(self, answer):
        expected_answer = 3
        if answer == expected_answer:
            self.total_score += 5
            print("Correct! You scored 5 points.")
        else:
            print(f"Incorrect. You scored 0 points.")

    def Q3(self, answer):
        expected_answer = 3.0
        if answer == expected_answer:
            self.total_score += 5
            print("Correct! You scored 5 points.")
        else:
            print(f"Incorrect. You scored 0 points.")

    def Q4(self, answer):
        expected_answer = 0.0
        if answer == expected_answer:
            self.total_score += 10
            print("Correct! You scored 10 points.")
        else:
            print(f"Incorrect. You scored 0 points.")

    def Q5(self, answer):
        expected_answer = "Maggie" * 100
        if answer == expected_answer:
            self.total_score += 10
            print("Correct! You scored 10 points.")
        else:
            print(f"Incorrect. The correct answer is '{expected_answer}'. You scored 0 points.")


    def Q6(self, print_function):
            expected_output = "I'd love to play, but my mom's friend 'Deb' is coming. I have to stay at home."
            captured_output = io.StringIO()
            sys.stdout = captured_output
            print_function()
            sys.stdout = sys.__stdout__
            if captured_output.getvalue().strip() == expected_output:
                self.total_score += 10
                print("Correct! You scored 10 points.")
            else:
                print(f"Incorrect. The expected output is '{expected_output}'. You scored 0 points.")

    def Q7(self, print_function):
        expected_output = "William Shakespeare was \nborn on April 23, 1564, \nin Stratford-upon-Avon.\nThe son of John Shakespeare and Mary Arden"
        captured_output = io.StringIO()
        sys.stdout = captured_output
        print_function()
        sys.stdout = sys.__stdout__
        if captured_output.getvalue().strip() == expected_output:
            self.total_score += 10
            print("Correct! You scored 10 points.")
        else:
            print(f"Incorrect. The expected output is '{expected_output}'. You scored 0 points.")
